package java2;

public class mssql {
	

	public void abc() {
		
		System.out.println("외부 클래스 로드 완료");
	}
	
	public String bbb() {
		String user = "홍길동";
		return user;
	}
	
	public static void main(String[] args) {
		System.out.println("외부 클래스 로드 완료");
	}
}

//
//
//https://github.com/gongmeP/java.git
//
//
//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 
