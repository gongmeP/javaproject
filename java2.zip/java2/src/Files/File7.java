package Files;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class File7 {

	public static void main(String[] args) {
		mem123 abb = new mem123();
		try {

			abb.aaa();
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}

class mem123 {
    FileReader fw1;
    Scanner sc1;

    public void aaa() throws Exception {
        ArrayList<ArrayList<String>> all = new ArrayList<>();
        this.fw1 = new FileReader("E:\\git_java\\javaproject\\java2\\src\\Files\\member.txt");
        this.sc1 = new Scanner(this.fw1);

        while (this.sc1.hasNext()) {
            String datas = this.sc1.nextLine();
            String[] sdata = datas.split(",");
            ArrayList<String> abc = new ArrayList<>(Arrays.asList(sdata));
            all.add(abc);
        }
        
        System.out.println(all);
    }
}




//
//
//
//class mem123 {
//	Scanner sc1;
//	FileReader fw1;
//	
//	String sdata[];
//	public void aaa() throws Exception {
//		ArrayList<String> abc1 = new ArrayList<>();
//		ArrayList<String> abc2 = new ArrayList<>();
//		ArrayList<ArrayList<String>> all = new ArrayList<>();
//		this.fw1 = new FileReader("E:\\git_java\\javaproject\\java2\\src\\Files\\member.txt");
//		this.sc1 = new Scanner(this.fw1);
//
//		String datas;
//		int cnt=0;
//		while (this.sc1.hasNext()) {
//
//			datas = this.sc1.nextLine();
//			sdata= datas.split(",");
//			int x = 0;
//			while(x < sdata.length) {
//				if(cnt == 0) {
//					
//					abc1.add(sdata[x]);
//					x++;
//					
//				}else if(cnt == 1) {
//					abc2.add(sdata[x]);
//					x++;
//				}
//			}
//			System.out.println(Arrays.toString(sdata));
//			cnt++;
//		}
//		all.add(abc1);
//		all.add(abc2);
//		
//		System.out.println(all);
//
//
//	}
//
//}
