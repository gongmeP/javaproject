package project1;

public interface numinter {
	
	Integer number = (int) Math.ceil(Math.random() * 10);
	
	public void games();

}
