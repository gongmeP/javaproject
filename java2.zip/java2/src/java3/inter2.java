package java3;

public interface inter2 {
	String names = "이순신";
	public void z2();
	public String z3();
	

}
