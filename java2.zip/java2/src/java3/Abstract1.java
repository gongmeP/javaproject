//package java3;
//
////추상 클래스(가상 클래스)
//public class Abstract1 {
//
//	public static void main(String[] args) {
//
//	}
//
//
//}
//class box2 extends box{
//	@Override
//	public void sbox() {
//		
//		
//	}
//	String result() {
//		return null;
//	}
//}
//
//abstract class box{
//	abstract public void sbox():
//		abstract String result();
//}
//abstract : 추상 메소드가 존재하며, 해당 추상 메소드를 사용하지 않을경우 (오버라이딩) 에러발생
