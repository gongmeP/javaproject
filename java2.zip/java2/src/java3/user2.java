package java3;

public interface user2 {
	
	String infodata[][] = {
		{"hong","홍길동","서울시 영등포구","01012345678","5000"},
		{"hongapink","홍길동","서울시 마포구","01056471122","1200"},
		{"kim","김유신","인천광역시","01022334787","1000"},
		{"jang","장보고","경상북도 문경시","010223369","8000"},
		{"kangkam_chan","강감찬","전라남도 부안시","01033226987","3200"}
	};
	
	public String pointck(String userid);
	public void myinfo(String userid);

}
