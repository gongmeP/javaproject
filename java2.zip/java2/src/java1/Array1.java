package java1;

public class Array1 {

	// 배열1
	public static void main(String[] args) {
		String user[] = { "홍길동", "이순신", "강감찬" };
		System.out.println(user[1]);
		int ea = user.length;
		System.out.println(ea);

		// 숫자 배열 형태
		int number[] = { 1, 2, 3, 4, 5 };
		System.out.println(number[0]);
	}

}
