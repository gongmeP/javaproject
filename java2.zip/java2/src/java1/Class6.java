package java1;

public class Class6 {

	// 상수 성언하는 방법 + 외부 클래스 메소드 이동

	public static void main(String[] args) {
		int a = 5;
		final int b = 10; // final : 상수를 선언하는 자료형
		a = 10;

		System.out.println(a);
		System.out.println(b);

		String id = "hong";

		User u = new User(id);

	}
}

class User {
	String person; // 필드에 있는 인스턴스 변수(전역변수)

	public User(String id) { // 기본 메소드 . 즉시실행 메소드는 무조건 Class명과 동일해야함
		person = "홍길동"; // 인스턴스 변수에 값을 이관
		System.out.println(id);
		list(); // 메소드를 바로 호출이 가능함
	}

	public void list() { // 즉시실행 메소드안에서 실행된 메소드
		System.out.println(person);
		System.out.println("사용자 리스트 출력");
		int p = point(); // return 메소드로 값을 이관받아서 처리
		System.out.println(p);
	}

	public int point() {
		return 5000;
	}
}
