package java1;

// 11버전 이상 가능
public class Switch2 {

	public static void main(String[] args) {
		
//		int aa = 1;
//		switch(aa) {
//		case 1 ->{
//			System.out.println("숫자 1선택");
//		}
//		case 2 ->{
//			System.out.println("숫자 2선택");
//			
//		}
//		default -> {
//			System.out.println("다음 기회에");
//		}
//		
//		}
	}

}
