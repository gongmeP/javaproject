/**
 * 
 */
/**
 * @author Administrator
 *
 */
module java2 {
}